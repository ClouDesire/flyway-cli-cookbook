CREATE TABLE test ( id integer PRIMARY KEY );
